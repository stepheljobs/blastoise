var fs = require('fs')
    , http = require('http')
    , https = require('https')
    , fs = require('fs')
    , socketio = require('socket.io')
    , mysql  = require('mysql')
    , express = require('express')
    , app = express()
    , server
	, connection = mysql.createConnection({
		  host     : 'localhost',
		  user     : 'root',
		  password : '',
		  port     : 3306,
		  database : "ipostmo_notifications",
		  multipleStatements: true
	   });

app.disable('x-powered-by');
app.use(function (req, res, next) {
  /*res.header('Access-Control-Allow-Origin', config.cors.origin);
  res.header('Access-Control-Allow-Methods', config.cors.methods);
  res.header('Access-Control-Allow-Headers', config.cors.headers);
  */

  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   
next();
});

app.get('*', function (req, res) {
  res.write("Im ALive and Kicking...")
});

var ISHTTPS = true;
if(! ISHTTPS){
	 server = http.createServer(app);
	  console.log('Listening at http: port:8080');
 	//OLD CODE
 	server = http.createServer(function(req, res) {
    		res.writeHead(200, { 'Content-type': 'text/html'});
    		//res.end(fs.readFileSync(__dirname + '/index.html'));
    		res.write("ddddd")
	}).listen(3000, function() {
    		console.log('Listening at http: port:8080');
	});
	
}else{
	server = https.createServer({
    	ca: fs.readFileSync("/home/admin/ssl/crosr.com.pem"),
    	key: fs.readFileSync("/home/admin/ssl/crosr.com.pem"),
   		cert: fs.readFileSync("/home/admin/ssl/crosr.com.pem")
  	}, app);
  	 console.log('Listening at https: port:3000');

	/*OLD CODE
	var options = {
  		key: fs.readFileSync('ssl-ipostmo/ipostmo-2016.com.pem'),
  		cert: fs.readFileSync('ssl-ipostmo/ipostmo-2016.com.pem'),
		cert: fs.readFileSync('ssl-ipostmo/ipostmo-2016.com.pem')
	};
        server = https.createServer(options, function(req, res) {
                res.writeHead(200, { 'Content-type': 'text/html'});
                //res.end(fs.readFileSync(__dirname + '/index.html'));
                res.write("ddddd")
        }).listen(3000, function() {
                console.log('Listening at https: port:3000');
        });
	*/
}

server.listen(3000);


var io = socketio.listen(server);
io.on('connection', function (socket) {
	var CURRENT_ROOM =   0;

	socket.on('join-room', function (roomId) {
        socket.join(roomId);
        CURRENT_ROOM = roomId;
        console.log("You have successfully joined a room." + roomId);
    });
    socket.on('test', function (msg) {
        console.log('Message Received: ', msg);
        socket.broadcast.to(CURRENT_ROOM).emit('test', msg);

    });




	//FOR MESSAGES
	//when a recipient sends a message
	socket.on("sendMessage", function (data) {
console.log("SUCCESSFULLY SEND A MESSAGE-->> TO:" +CURRENT_ROOM + " send data:" + data  );
		var sender = CURRENT_ROOM;
		var message = {
			sender: sender,
			recipient: data.recipient,
			message: data.message,
			date: new Date(),
			read: 1
		}
console.log("sending message---->>>>>>" + JSON.stringify(message));
		connection.query('select * from message_tagger having combined_user_id = concat(?, "_", ?) or combined_user_id = concat(?, "_", ?)', [sender, data.recipient, data.recipient, sender], function (_error, _result) {
				if(_result.length == 0){ 
					connection.query('insert into message_tagger set ?', {combined_user_id: sender + "_" + data.recipient , mt_sender: sender, mt_recipient: data.recipient}, function (__error, __result) {
							message.message_tagger = __result.insertId;

							connection.query('insert into messages set ?', message, function (error, result) {

connection.query('select m.*, m.message as  message, m.date as date, concat(recipient.fullname) as recipient_fullname, concat(sender.fullname) as sender_fullname from messages m left join users recipient on recipient.id = m.recipient left join users sender on sender.id = m.sender where m.id = ? limit 1', __result.insertId, function (m_error, m_result) {
									socket.emit('loadNewMessage_' + sender, m_result[0]);
									io.emit('loadNewMessage_' + data.recipient, m_result[0]);
         countUnreadMessages();
		});		

});
							connection.query('update message_tagger set `last_seen_date` = ? where id = ?', [(new Date()), message.message_tagger  ], function (_error, _result) {

							});
					});		

					
				}else{
					message.message_tagger = _result[0].id;
					connection.query('insert into messages set ?', message, function (error, result) {
							socket.emit('loadNewMessage_' + sender, message);
							io.emit('loadNewMessage_' + data.recipient, message);
               
countUnreadMessages();
					});		
					connection.query('update message_tagger set `last_seen_date` = ? where id = ?', [(new Date()), message.message_tagger  ], function (_error, _result) {

					});

				}
		});
	});

	
	socket.on("countUnreadMessages", function(data){
		countUnreadMessages();
	});              


         function  countUnreadMessages(){
console.log("COUNT UNREAD MESSAGES.. NOTIFY SENDER.....");
		var sender = CURRENT_ROOM;
		connection.query("select sum(m.read) as unread_count from messages m where recipient = ? and read = 0 limit 1", [sender], function (error, result) {				

                       if(result == null){
socket.emit('showUnreadMessages_' + sender, 0);
}else{
				socket.emit('showUnreadMessages_' + sender, result[0].unread_count);
}
		});
}             
	//retrieve all conversation of users to his/her recipient
	socket.on("loadUserConversations" , function (data) {
		var sender = CURRENT_ROOM;
			start = data.start;
			limit = data.limit;
			console.log("DATAA....." + data);
			//

			//connection.query("select mt.combined_user_id, mt.id as mt_id,  m.*, sum(m.read) as unread_count, u.fullname from message_tagger mt left join on messages m  left join users u on u.id = m.recipient where sender = ? group by recipient order by id asc limit ?, ?", [sender,  start, limit], function (error, result) {	
			//connection.query("select m.*, sum(m.read) as unread_count, u.fullname from messages m left join users u on u.id = m.recipient where sender = ? or recipient = ? group by recipient order by id asc limit ?, ?", [sender, sender, start, limit], function (error, result) {				
			//connection.query("select mt.combined_user_id, mt.id as mt_id,  m.*, sum(m.read) as unread_count, u.fullname from message_tagger mt left join messages m on mt.id = m.message_tagger left join users u on u.id = m.recipient where mt.combined_user_id like '%" + sender+  "%' group by mt.id order by id asc limit ?, ?", [  start, limit], function (error, result) {	
			//"select * from message_taggger mt left join users sender on sender.id = mt.sender left join on users recipient on recipient.id = mt.recipient"
			connection.query("select mt.id as id,mt.last_seen_date as date, mt.combined_user_id, mt_sender, mt_recipient, recipient.fullname as recipient, sender.fullname sender from message_tagger mt left join users sender on sender.id = mt.mt_sender left join users recipient on recipient.id = mt.mt_recipient where mt.combined_user_id like '%" +sender + "%' order by last_seen_date limit ?,?", [start, limit], function (error, result) {	

				console.log(this.sql);
				socket.emit('loadUserConversations_' + sender, result);
			});
	});

	//retrieve conversation by recipient
	socket.on("loadConversation" , function (data) {
		var sender = CURRENT_ROOM;
			recipient = data.recipient;
			start = data.start;
			limit = data.limit;


			connection.query('select * from message_tagger having combined_user_id = concat(?, "_", ?) or combined_user_id = concat(?, "_", ?) limit 1', [sender, data.recipient, data.recipient, sender], function (_error, _result) {
				if(_result.length > 0){ 
					console.log("--->>TAGGER... " + JSON.stringify(_result) + "--->>" + _result[0].id);
					var message_tagger = _result[0].id;
					connection.query("select m.* from messages m where message_tagger = ? order by id asc limit ?, ?", [message_tagger, start, limit], function (error, result) {				
						//console.log(this.sql);
						socket.emit('loadConversation_' + sender, result);

					});
					connection.query('update messages m set m.read = 0 where where message_tagger = ?', [message_tagger] , function (error, result) {   
						console.log("ALL MESSAGES ARE NOW READ....");
					});
					
				}

			});

	});

    //SAVING OF NOTIICATION
    socket.on('notify', function (userNotif) {
    	 processNotification(userNotif);
	});

	//NOTIFY SUBSCRIBERS
    socket.on('notifySubscribers', function (userNotif) {
    	var notifMessage = {
			message: userNotif.message,
			type: userNotif.type,
			created_at: new Date()
		};
                console.log("-->>>" +  JSON.stringify(notifMessage));
		connection.query('insert into notification_messages set ?', notifMessage, function (error, result) {
			console.log(JSON.stringify(result));
			connection.query('select distinct(subscriber_id) from subscribers where user_id = ?', [userNotif.user_id], function (subscriberError, subscriberResult) {				
			         console.log("DISTINCT USERS-->>  " + JSON.stringify(subscriberResult) );
                                console.log("----->>>>" +  this.sql);
			       	for(var i = 0; i < subscriberResult.length; i++){
					var subscriberNotif = {
						user_id: subscriberResult[i].subscriber_id,
						notified_by: userNotif.user_id,
						notification_message_id: result.insertId
					}
					saveNotification(subscriberNotif);
				}
			});

		});
	});

    //##COUNT NOTIFICATION
	//required data: user_id, viewed
	socket.on('countNotification', function (notif) {
		connection.query('select count(1) as count from notifications where `user_id` = ? and `viewed` = ? limit 1', [notif.user_id, notif.viewed], function (error, result) {
			socket.emit("showTotalNotification", result[0].count);
		});
    });

	//##VIEW PER NOTIFICATIONS PER USER
	//required data: user_id
	socket.on('viewUserNotifications', function (notif) {
		connection.query('select notif.id, username, fullname, notif_message.created_at, notif.user_id, notified_by, type, message, viewed from notifications notif left join notification_messages notif_message on notif_message.id = notif.notification_message_id left join users u on u.id = notif.user_id where notif.user_id = ? order by notif.id asc limit ?, ? ', [notif.user_id, notif.record_start, notif.number_of_records], function (error, result) {
			//console.log("SQL:::: " + this.sql);
			socket.emit("showNotificationList", JSON.stringify(result));
console.log("NO ERROR SO FAR...");
                                connection.query('UPDATE `notifications` SET `viewed` = 0  and `user_id` = ?', [ CURRENT_ROOM] , function (errorInNotif, notifUpdateResult) {
                                        notif.viewed = 1;
                        console.log("something.... update called...." + this.sql);
                     connection.query('select count(1) as count from notifications where `user_id` = ? and `viewed` = ? limit 1', [CURRENT_ROOM, notif.viewed], function (error, result) {
                        console.log("SOCKET.EMIT..." + result[0].count );
 socket.emit("showTotalNotification", result[0].count);
                });
//      countNotifications(notif);
                                });

		});
	 });

	//##VIEW PER NOTIFICATION ID AND USER ID
	//required data: id(notification) ,user_id
	socket.on('viewNotification', function (notif) {
		connection.query('select notif.id, username, fullname, notif_message.created_at, notif.user_id, notified_by, type, message, viewed from notifications notif left join notification_messages notif_message on notif_message.id = notif.notification_message_id left join users u on u.id = notif.user_id  where notif.user_id = ? and notif.id = ?', [notif.user_id, notif.id], function (error, result) {
			var isValid = false;
			var notifLink = "";
console.log("VIEW NOTIFICATION CALLED.....");
			if(error || result.length == 0){
console.log("THERE'S ERROR");
			}else{
				isValid = true;

				notifLink = "/";
console.log("NO ERROR SO FAR...");
				connection.query('UPDATE `notifications` SET `viewed` = 0 where `id` = ? and `user_id` = ?', [notif.id, notif.user_id] , function (errorInNotif, notifUpdateResult) {   
					notif.viewed = 1;
			console.log("something.... update called...." + this.sql);	
                     connection.query('select count(1) as count from notifications where `user_id` = ? and `viewed` = ? limit 1', [notif.user_id, notif.viewed], function (error, result) {
			console.log("SOCKET.EMIT..." + result[0].count );                       
 socket.emit("showTotalNotification", result[0].count);
                });
//	countNotifications(notif);
				});
			}
			socket.emit("viewNotification", {valid: isValid, link: notifLink, notification: result});
			
		});
	 });

	//##SUBSCRIBERS
	//id, user_id, subscriber_id, status, created_at


	//SAVING OF SUBSCRIBERS
	//required data:  user_id, subscriber_id
	socket.on('subscribe', function (data) {
                console.log("SUBSCRIBE CALLED...");
		var subscriber = {
			user_id: data.user_id,
			subscriber_id: data.subscriber_id,
			status : 1,
			subscribe_date : new Date()

		};
console.log("---->>>.>" + JSON.stringify(subscriber));
		connection.query('select count(1) as count from subscribers where user_id = ? and subscriber_id = ?', [subscriber.user_id, subscriber.subscriber_id], function (_error, _result) {
console.log("SQL......." + this.sql);		
	if(_result[0].count == 0){

				connection.query('insert into subscribers set ?', subscriber, function (error, result) {
					// socket.broadcast.to(CURRENT_ROOM).emit("subscribeResult", "success");
console.log("-------->>>>SUCCESSFULLY INSERTED SUBSCRIBER");
				 	io.in(CURRENT_ROOM).emit("subscribeResult", {message : "success"});
					var subscriberNotif = {
						user_id: subscriber.user_id,
						notified_by: subscriber.subscriber_id,
						notification_message_id: result.insertId,
						message: data.message,
						type: "SUBS",
					}
					 processNotification(subscriberNotif);
				});
			}else{
				// socket.broadcast.to(CURRENT_ROOM).emit("subscribeResult", {message : "failed"});
				  io.in(CURRENT_ROOM).emit("subscribeResult", {message : "failed"});
			}
		});

	});



	socket.on('saveNewUser', function (data) {
		connection.query('insert into `users` set ?', data, function (error, result) {

		});
	});

	socket.on('updateUser', function (data) {
		connection.query('UPDATE `users` SET `username` = "'+ data.username +'", `fullname` = "'+ data.fullname +'" WHERE `id` = "' + data.id + '"', function (error, result) {   

		});
	});

	//REPEATED FUNCTIONS

	function processNotification(userNotif){
		var notifMessage = {
			message: userNotif.message,
			type: userNotif.type,
			created_at: new Date()
		};
		connection.query('insert into notification_messages set ?', notifMessage, function (error, result) {
			//if(!error){
					//NOTIFY ONE NOTIFICATION
					var notification = {
						user_id: userNotif.user_id,
						notified_by: userNotif.notified_by,
						notification_message_id : result.insertId,
						created_at: new Date()
					}
					saveNotification(notification);
			//}
		});
	}


	function saveNotification(userNotif){
		userNotif["last_viewed_at"] = new Date();
		userNotif["created_at"] = new Date();
		connection.query('insert into notifications set ?', userNotif , function (error, result) {
			
			connection.query('select notif.id, username, fullname, notif_message.created_at, notif.user_id, notified_by, type, message, viewed from notifications notif left join notification_messages notif_message on notif_message.id = notif.notification_message_id left join users u on u.id = notif.user_id  where notif.user_id = ? and notif.id = ?', [userNotif.user_id, result.insertId], function (_error, newlyInsertedNotification) {
				io.emit("processNewNotifications", newlyInsertedNotification);
				//socket.emit("viewNotification", {valid: isValid, link: notifLink, notification: result});
			});
		});
	}

});




